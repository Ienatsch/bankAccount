/** File Prologue
 * Name: Jacob Maughan & Dolan Lenatsch
 * Assignment: Final Project
 * Date: 03/15/19 - 4/10/19
 * CIT260
 */
package bankAccountProject;

import java.util.Scanner;
import java.io.*;
public class BankAccountTest {

	public static void main(String[] args) {
		// Declare the scanner 
		Scanner input =  new Scanner(System.in);

	}

}
